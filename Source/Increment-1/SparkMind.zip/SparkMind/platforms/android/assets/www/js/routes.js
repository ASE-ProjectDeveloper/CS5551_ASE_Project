angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    
  

      .state('menu.spark4Mind', {
    url: '/page1',
    views: {
      'side-menu21': {
        templateUrl: 'templates/spark4Mind.html',
        controller: 'spark4MindCtrl'
      }
    }
  })

  .state('menu.myProgess', {
    url: '/page2',
    views: {
      'side-menu21': {
        templateUrl: 'templates/myProgess.html',
        controller: 'myProgessCtrl'
      }
    }
  })

  .state('menu.settings', {
    url: '/page3',
    views: {
      'side-menu21': {
        templateUrl: 'templates/settings.html',
        controller: 'settingsCtrl'
      }
    }
  })

  .state('menu', {
    url: '/side-menu21',
    templateUrl: 'templates/menu.html',
    controller: 'menuCtrl'
  })

  .state('menu.login', {
    url: '/page4',
    views: {
      'side-menu21': {
        templateUrl: 'templates/login.html',
        controller: 'loginCtrl'
      }
    }
  })

  .state('signup', {
    url: '/page5',
    templateUrl: 'templates/signup.html',
    controller: 'signupCtrl'
  })

  .state('spark4Mind2', {
    url: '/page6',
    templateUrl: 'templates/spark4Mind2.html',
    controller: 'spark4Mind2Ctrl'
  })

  .state('menu.stressTest', {
    url: '/page7',
    views: {
      'side-menu21': {
        templateUrl: 'templates/stressTest.html',
        controller: 'stressTestCtrl'
      }
    }
  })

$urlRouterProvider.otherwise('/page6')

  

});