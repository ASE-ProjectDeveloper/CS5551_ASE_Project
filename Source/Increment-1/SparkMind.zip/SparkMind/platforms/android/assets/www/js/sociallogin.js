
        function Log()
        {
            if(document.getElementById('username').value.length>0 && document.getElementById('pwd').value.length>0)
            {
                    if(document.getElementById('username').value==localStorage.getItem('userName')
                            && document.getElementById('pwd').value==localStorage.getItem('pwd'))
                    {
                        window.location.href='Homepage.html';
                    }
                else
                    {
                        alert('Enter correct information');
                    }
            }
            else
            {
                alert('Missing information !');
            }
        }

        function onSuccess(googleUser) {
            var profile = googleUser.getBasicProfile();
            gapi.client.load('plus', 'v1', function () {
                var request = gapi.client.plus.people.get({
                    'userId': 'me'

                });
                //Display the user details
                request.execute(function (resp) {
                    var profileHTML = '<div class="profile"><div class="head">Welcome '+resp.name.givenName+'! <a href="javascript:void(0);" onclick="signOut();">Sign out</a></div>';
                    profileHTML += '<img src="'+resp.image.url+'"/><div class="proDetails"><p>'+resp.displayName+'</p><p>'+resp.emails[0].value+'</p><p>'+resp.gender+'</p><p>'+resp.id+'</p><p><a href="'+resp.url+'">View Google+ Profile</a></p></div></div>';
                    $('.userContent').html(profileHTML);
                    $('#gSignIn').slideUp('slow');
                });
            });
        }
        function onFailure(error) {
            alert(error);
        }
        function renderButton() {
            gapi.signin2.render('gSignIn', {
                'scope': 'profile email',
                'width': 240,
                'height': 50,
                'longtitle': true,
                'theme': 'dark',
                'onsuccess': onSuccess,
                'onfailure': onFailure
            });
        }
        function signOut() {
            var auth2 = gapi.auth2.getAuthInstance();
            auth2.signOut().then(function () {
                $('.userContent').html('');
                $('#gSignIn').slideDown('slow');
            });
        }

        window.fbAsyncInit = function () {
            FB.init({
                appId: '542565789278690',
                xfbml: true,
                version: 'v2.7'
            });
            FB.getLoginStatus(function (response) {
                if (response.status === 'connected') {
                    document.getElementById('status').innerHTML = 'We are connected to FaceBook';
                } else if (response.status === 'not_authorized') {
                    document.getElementById('status').innerHTML = 'We are not connected to FaceBook';
                } else{
                    document.getElementById('status').innerHTML = 'We are not logged into FaceBook';
                }
            });
        };
        (function(thisdocument, scriptelement, id) {
            var js, fjs = thisdocument.getElementsByTagName(scriptelement)[0];
            if (thisdocument.getElementById(id)) return;
            js = thisdocument.createElement(scriptelement); js.id = id;
            js.src = "//connect.facebook.net/en_US/sdk.js"; //you can use
            fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));
        function  login() {
            FB.login(function (response) {
                if (response.status === 'connected') {
                    self.location="welcome.html";
                    document.getElementById('status').innerHTML = 'We are connected to FaceBook';
                } else if (response.status === 'not_authorized') {
                    document.getElementById('status').innerHTML = 'We are not connected to FaceBook';
                } else{
                    document.getElementById('status').innerHTML = 'We are not logged into FaceBook';
                }window.fbAsyncInit = function () {
                    FB.init({
                        appId: '2135410813349850',
                        xfbml: true,
                        version: 'v2.7'
                    });
                    FB.getLoginStatus(function (response) {
                        if (response.status === 'connected') {
                            document.getElementById('status').innerHTML = 'We are connected to FaceBook';
                        } else if (response.status === 'not_authorized') {
                            document.getElementById('status').innerHTML = 'We are not connected to FaceBook';
                        } else{
                            document.getElementById('status').innerHTML = 'We are not logged into FaceBook';
                        }
                    });
                };
                (function(thisdocument, scriptelement, id) {
                    var js, fjs = thisdocument.getElementsByTagName(scriptelement)[0];
                    if (thisdocument.getElementById(id)) return;
                    js = thisdocument.createElement(scriptelement); js.id = id;
                    js.src = "//connect.facebook.net/en_US/sdk.js"; //you can use
                    fjs.parentNode.insertBefore(js, fjs);
                }(document, 'script', 'facebook-jssdk'));
                function  login() {
                    FB.login(function (response) {
                        if (response.status === 'connected') {
                            self.location="welcome.html";
                            document.getElementById('status').innerHTML = 'We are connected to FaceBook';
                        } else if (response.status === 'not_authorized') {
                            document.getElementById('status').innerHTML = 'We are not connected to FaceBook';
                        } else{
                            document.getElementById('status').innerHTML = 'We are not logged into FaceBook';
                        }
                    });
                }
            });
        }